﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace lab2_waalberg
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            error.Visible = false;
        }

        protected void convert_Click(object sender, EventArgs e)
        {
            error.Visible = false;
            float far;
            float cel;
            
            if (f.Text != "" && c.Text != "")
            {
                error.Text = "Enter one value only.";
                error.Visible = true;
                return;
            }

            if (f.Text != "" && c.Text == "")
            {
                try
                {
                    far = float.Parse(f.Text);
                    cel = ((float)5/9) * (far - 32);
                    c.Text = cel.ToString();
                    error.Visible = false;
                }
                catch
                {
                    error.Text = "Enter a number.";
                    error.Visible = true;
                    return;
                }
            }

            if (f.Text == "" && c.Text != "")
            {
                try
                {
                    cel = float.Parse(c.Text);
                    far = (cel * ((float)9/5)) + 32;
                    f.Text = far.ToString();
                    error.Visible = false;
                }
                catch
                {
                    error.Text = "Enter a number.";
                    error.Visible = true;
                    return;
                }
            }
        }

        protected void clear_Click(object sender, EventArgs e)
        {
            error.Text = "Error";
            error.Visible = false;
            f.Text = "";
            c.Text = "";
        }
    }
}