﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Linq;
using System.Web;


public partial class Default : System.Web.UI.Page
{
    
    void make_str(string in_str, int f, int e, ref int numAnagrams, bool no_dup)
    {
        int length = in_str.Length;
        if (f == e)
        {

            if (no_dup == true)
            {
                ListItem item = display.Items.FindByText(in_str);
                if (item != null)
                    return;
            }

            display.Items.Add(in_str);
            numAnagrams++;
            return;
        }


        for (int i = f; i <= e; i++)
        {
            in_str = switch_c(in_str, length, f, i);
            make_str(in_str, f + 1, e, ref numAnagrams, no_dup);
            in_str = switch_c(in_str, length, f, i);
        }


    }
    string switch_c(string str, int len, int indexf, int indexe)
        {
            string str1 = "";
        
            char tmp_indexe = str[indexe];

            char tmp_indexf = str[indexf];

            for (int i = 0; i < len; i++)
            {
                if (i == indexf)
                    str1 += tmp_indexe;
                else if (i == indexe)
                    str1 += tmp_indexf;
                else
                    str1 += str[i];
            }
            return str1;
        }

    public void make_anag(object sender, EventArgs e)
    {

        display.Items.Clear();
        int numAnagrams = 0;
        bool no_dup = false;


        string input = in_str.Text;
        int in_length = input.Length;
        if (in_length > 8 || in_length < 1)
        {
            comment.Text = "Please enter a string from 1 to 8 characters.";
            in_str.Text = "";
            return;
        }


        if (remove_dup.Checked)
            no_dup = true;
        make_str(input, 0, in_length - 1, ref numAnagrams, no_dup);
        if (numAnagrams == 1)
            comment.Text = numAnagrams + " anagram found.";
        else
            comment.Text = numAnagrams + " anagrams found.";


        in_str.Text = ""; // clear the textbox
    }




}