﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace lab4_waalberg
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            errorcode.Visible = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            errorcode.Visible = false;
            errorcode.Text = "Invalid Input: ";
            double input_factor;
            double output_factor;
            double input_val;
            double meters;
            double res;
            try
            {
                input_factor = Convert.ToDouble(DropDownList1.SelectedValue);
                input_val = double.Parse(TextBox1.Text);
                meters = input_val * input_factor;
                output_factor = Convert.ToDouble(DropDownList2.SelectedValue);
                res = meters / output_factor;
                TextBox2.Text = res.ToString();
                errorcode.Visible = false;
                if (input_factor == output_factor)
                {
                    errorcode.Text = "Cannot convert to same unit.";
                    TextBox2.Text = "Not available.";
                    errorcode.Visible = true;
                }
            }
            catch (System.FormatException)
            {
                errorcode.Text += "A unit must be selected and input must be a number.";
                errorcode.Visible = true;
                TextBox1.Text = "";
                TextBox2.Text = "Not available.";
                return;
            }
        }
    }
}