﻿SET IDENTITY_INSERT [dbo].[Votes] ON
INSERT INTO [dbo].[Votes] ([Id], [name], [count]) VALUES (1, N'resaurant1', 0)
INSERT INTO [dbo].[Votes] ([Id], [name], [count]) VALUES (2, N'resaurant2', 0)
INSERT INTO [dbo].[Votes] ([Id], [name], [count]) VALUES (3, N'resaurant3', 0)
INSERT INTO [dbo].[Votes] ([Id], [name], [count]) VALUES (4, N'restaurant4', 0)
INSERT INTO [dbo].[Votes] ([Id], [name], [count]) VALUES (5, N'restaurant5', 0)
INSERT INTO [dbo].[Votes] ([Id], [name], [count]) VALUES (6, N'restaurant6', 0)
SET IDENTITY_INSERT [dbo].[Votes] OFF
